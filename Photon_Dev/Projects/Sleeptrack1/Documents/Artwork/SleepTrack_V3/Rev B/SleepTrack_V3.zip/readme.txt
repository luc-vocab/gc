1) Tent all vias on top side of board.
2) During assembly check for short between VCC and GND. Specifically after soldering the Photon P1 (U7). If short exists please notify us.3
3) Source/Supply R1 (330R), BOM Item # 20 for assembly.
