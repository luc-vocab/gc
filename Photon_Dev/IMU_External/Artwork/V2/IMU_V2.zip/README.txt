1) Tent vias on Top side
2) 